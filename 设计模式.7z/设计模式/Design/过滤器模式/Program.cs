﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 过滤器模式
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> persons = new List<Person>();
            persons.Add(new Person("Mike", "Female", 24, "Married"));
            persons.Add(new Person("Cake", "Male", 35, "Married"));
            persons.Add(new Person("Windy", "Male", 20, "Single"));
            persons.Add(new Person("Katy", "Male", 14, "Single"));
            persons.Add(new Person("Jake", "Female", 24, "Single"));
            persons.Add(new Person("Feifei", "Female", 24, "Married"));
            persons.Add(new Person("Candy", "Male", 25, "Married"));

            Filter genderFilter = new GenderFilter("Male");
            Filter ageFilter = new AgeFilter(24);
            Filter singleFilter = new SingleFilter();
            Filter andFilter = new AndFilter(genderFilter, ageFilter, singleFilter);
            Filter orFilter = new OrFilter(ageFilter, singleFilter);

            Console.WriteLine("Young Male Single Person ");
            PrintPersons(orFilter.MeetFilter(persons));
            Console.ReadKey();


        }

        public static void PrintPersons(List<Person> persons)
        {
            foreach (var person in persons)
            {
                Console.WriteLine($"Person:[Name:{person.Name},Gender:{person.Gender},Age:{person.Age},MaritalStatus:{person.MaritalStatus}]");
            }
        }
    }

    public class Person
    {
        public Person(string name, string gender, int age, string maritalStatus)
        {
            this.Name = name;
            this.Gender = gender;
            this.Age = age;
            this.MaritalStatus = maritalStatus;
        }

        public string Name { get; set; }

        public string Gender { get; set; }

        public int Age { get; set; }

        public string MaritalStatus { get; set; }
    }

    public interface Filter
    {
        List<Person> MeetFilter(List<Person> persons);
    }

    public class GenderFilter : Filter
    {
        private string gender;

        public GenderFilter(string gender) {
            this.gender = gender;
        }
        public List<Person> MeetFilter(List<Person> persons)
        {
            return persons.Where(p => p.Gender.ToUpper().Equals(gender.ToUpper()))?.ToList();
        }
    }

    public class AgeFilter : Filter
    {
        private int age;

        public AgeFilter(int age)
        {
            this.age = age;
        }

        public List<Person> MeetFilter(List<Person> persons)
        {
            return persons.Where(p => p.Age<= age)?.ToList();
        }
    }


    public class SingleFilter : Filter
    {
        public List<Person> MeetFilter(List<Person> persons)
        {
            return persons.Where(p => p.MaritalStatus.ToUpper().Equals("SINGLE"))?.ToList();
        }
    }
    public class MarriedFilter : Filter
    {
        public List<Person> MeetFilter(List<Person> persons)
        {
            return persons.Where(p => p.MaritalStatus.ToUpper().Equals("MARRIED"))?.ToList();
        }
    }

    public class AndFilter : Filter
    {
        private List<Filter> filters = new List<Filter>();

        public AndFilter(params Filter[] filters)
        {
            foreach (var item in filters)
            {
                this.filters.Add(item);
            }
        }
        public List<Person> MeetFilter(List<Person> persons)
        {
            var filterPersons = new List<Person>(persons);
            foreach (var filter in filters)
            {
                filterPersons = filter.MeetFilter(filterPersons);
            }
            return filterPersons;
        }
    }

    public class OrFilter : Filter
    {
        private List<Filter> filters = new List<Filter>();

        public OrFilter(params Filter[] filters)
        {
            foreach (var item in filters)
            {
                this.filters.Add(item);
            }
        }
        public List<Person> MeetFilter(List<Person> persons)
        {
            var hashPersons = new HashSet<Person>();
            foreach (var filter in filters)
            {
                var filterPersons = filter.MeetFilter(persons);
                filterPersons?.ForEach(p => hashPersons.Add(p));
            }
            return hashPersons?.ToList();
        }
    }

}
